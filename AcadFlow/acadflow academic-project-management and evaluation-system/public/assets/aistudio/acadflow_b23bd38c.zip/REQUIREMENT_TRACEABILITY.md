# AcadFlow — Requirement Traceability Matrix

## 1. Traceability Overview
This document tracks all requirements for **AcadFlow — Academic Project Management and Evaluation System**, including original business specifications, the authoritative 4-role model, database entities, academic lifecycle workflows, supplementary features, and missing predecessor specifications.

Status Definitions:
- `PLANNED`: Feature is planned and scheduled in a phase.
- `IN_PROGRESS`: Actively under development in the current phase.
- `IMPLEMENTED_NOT_TESTED`: Implemented in codebase, pending automated test verification.
- `TESTED`: Implemented, executed against automated tests with verified pass output.
- `BLOCKED`: Dependency or original specification missing and formally requested.

---

## 2. Core Architectural & System Requirements

| Req ID | Requirement Name | Source | Frontend Dep | Backend Dep | Database Dep | Permissions | Acceptance Tests | Status |
|---|---|---|---|---|---|---|---|---|
| REQ-01 | Full-Stack Foundation & Health Endpoint | Master Prompt Sec 22 | React, Vite, Bootstrap 5 | Express.js, TypeScript | None (Phase 1) | Public | GET /api/health -> 200 OK | `TESTED` |
| REQ-02 | Centralized Error Handling | Master Prompt Sec 5, 22 | Error Alert UI | Express Error Middleware | None | All | Non-leak sanitized 500/404 JSON | `TESTED` |
| REQ-03 | Exactly 4 Application Roles Model | Master Prompt Sec 3 | Role Badge, Nav | Auth Middleware | Role Enum | Strict 4 roles | Ensure no 5th role exists | `TESTED` |
| REQ-04 | HOD Department Administration | Master Prompt Sec 3.1 | Admin Panel | Admin Routes, Services | Department, User | HOD Only | Scope isolation to dept & IDOR defense | `TESTED` |
| REQ-05 | Student Portal & Team Management | Master Prompt Sec 3.2 | Student Dashboard | Student Routes, Services | Team, Project | Student | Membership authorization & task toggles | `TESTED` |
| REQ-06 | Project Mentor Guidance & Tracking | Master Prompt Sec 3.3 | Mentor Dashboard | Mentor Routes, Services | MentorAssignment | Project Mentor | Assigned projects only & review tracking | `TESTED` |
| REQ-07 | External Evaluator Scoring & Rubrics | Master Prompt Sec 3.4 | Evaluator Dashboard | Evaluation Routes | Evaluation, Rubric | External Evaluator | Assigned evaluation states & rubric scoring | `TESTED` |
| REQ-08 | MySQL 8 + Prisma Persistence | Master Prompt Sec 5, 8 | Diagnostics UI | Prisma Client | MySQL 8 | DB User | Prisma validate, generate & migration DDL | `TESTED` |
| REQ-09 | Server-Side Secure Sessions & Auth | Master Prompt Sec 9 | Auth Views | express-session, bcrypt | UserSession | All | Session invalidation, rate limit, reset tokens | `TESTED` |
| REQ-10 | Private File Storage & Download Auth | Master Prompt Sec 10 | File Manager | Multer, Auth Stream | Document, Version | Resource-scoped | Path traversal, MIME check | `PLANNED` |
| REQ-11 | Notifications & Announcements | Master Prompt Sec 11 | Alert Dropdown | Notification Service | Notification | User-scoped | Read/unread state transitions | `PLANNED` |
| REQ-12 | PDF & Excel Reporting Engines | Master Prompt Sec 12 | Report Viewer | PDFKit, ExcelJS | Aggregated queries | Role-scoped | Formatted PDF/Excel generation | `PLANNED` |

---

## 3. Original 25 Additional Feature Areas (Predecessor Specification)

> **Notice per Master Prompt Sections 2 & 13:**
> The original AcadFlow Mega Prompt predecessor document containing the historical five-role model and the specific list of 25 named feature areas was searched for across the workspace. Only the final master prompt was provided in `/public/assets/aistudio/Paste_October_28__2026_-_9_39PM_e0380a3d`. Per directive: *"If the original specifications or feature list cannot be found, record the missing material as BLOCKED and request it. Do not claim that all original requirements have been inventoried or implemented."*

| Feature Area | Original Name | Source Document | Dependencies | Acceptance Test | Current Status | Notes |
|---|---|---|---|---|---|---|
| Area 01 | Original Feature 01 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 02 | Original Feature 02 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 03 | Original Feature 03 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 04 | Original Feature 04 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 05 | Original Feature 05 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 06 | Original Feature 06 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 07 | Original Feature 07 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 08 | Original Feature 08 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 09 | Original Feature 09 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 10 | Original Feature 10 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 11 | Original Feature 11 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 12 | Original Feature 12 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 13 | Original Feature 13 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 14 | Original Feature 14 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 15 | Original Feature 15 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 16 | Original Feature 16 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 17 | Original Feature 17 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 18 | Original Feature 18 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 19 | Original Feature 19 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 20 | Original Feature 20 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 21 | Original Feature 21 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 22 | Original Feature 22 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 23 | Original Feature 23 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 24 | Original Feature 24 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |
| Area 25 | Original Feature 25 | Historical Mega Prompt | Unknown | TBD | `BLOCKED` | Awaiting historical specification |

---

## 4. Supplementary Real-World Features (Master Prompt Section 14)

| Category | Feature Name | Description | Status |
|---|---|---|---|
| Academic Operations | Academic-year & Semester Management | Active term configuration & rollover | `PLANNED` |
| Academic Operations | Proposal Submission Windows | Strict opening/closing dates for student drafts | `PLANNED` |
| Academic Operations | Review Stages Configuration | Configurable stages (Inception, Midterm, Final) | `PLANNED` |
| Academic Operations | Rubric & Weight Configuration | Dynamic rubric criteria and weight limits | `PLANNED` |
| Academic Operations | Mentor Workload Balancing | Recommendations to prevent mentor overloading | `PLANNED` |
| Academic Operations | Duplicate Proposal Warnings | Title/abstract similarity detection | `PLANNED` |
| Student Productivity | Project Progress Timeline | Visual milestones, progress markers | `PLANNED` |
| Student Productivity | Personal Task Board | Kanban / status task tracking | `PLANNED` |
| Student Productivity | Submission Checklist | Pre-flight submission verification | `PLANNED` |
| Student Productivity | Portfolio & Resume Export | Clean portfolio summary generator | `PLANNED` |
| Student Productivity | Git Repository Integration | Repo URL association & metadata | `PLANNED` |
| Collaboration | Project Discussion Threads | Team comment threads & replies | `PLANNED` |
| Collaboration | Meeting Notes & Action Items | Structured mentor meeting minutes | `PLANNED` |
| Evaluation Integrity | Draft, Submitted & Finalized States | Strict transition rules on marks | `PLANNED` |
| Evaluation Integrity | Conflict of Interest Declaration | Evaluator COI declarations before scoring | `PLANNED` |
| Evaluation Integrity | Score Discrepancy & Moderation | Flagging outlier scores for HOD review | `PLANNED` |
| Governance | User Invitation Workflow | Token-based department invitations | `PLANNED` |
| Governance | Account Suspension & Reactivation | Audit-logged security account lifecycle | `PLANNED` |
| Governance | Exportable Audit Events | Structured security audit trail | `PLANNED` |
| User Experience | Responsive Layout & Dark Mode | Bootstrap 5 accessible interface | `PLANNED` |
