import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  FileText, 
  Award, 
  Bell, 
  Calendar, 
  ShieldCheck, 
  Download, 
  Search, 
  Megaphone, 
  Check, 
  Clock, 
  RefreshCw 
} from 'lucide-react';

interface SharedProps {
  currentUser: any;
  onRefresh: () => void;
}

export function SharedModulesHub({ currentUser, onRefresh }: SharedProps) {
  const [subTab, setSubTab] = useState<'reports' | 'notifications' | 'announcements' | 'calendar' | 'audit'>('reports');
  const [notifications, setNotifications] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [searchAudit, setSearchAudit] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [newAnnTitle, setNewAnnTitle] = useState<string>('');
  const [newAnnContent, setNewAnnContent] = useState<string>('');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const fetchSharedData = async () => {
    setLoading(true);
    try {
      const [notifRes, annRes, calRes] = await Promise.all([
        fetch('/api/notifications'),
        fetch('/api/announcements'),
        fetch('/api/calendar/events'),
      ]);

      if (notifRes.ok) {
        const data = await notifRes.json();
        setNotifications(data.notifications || []);
      }

      if (annRes.ok) {
        const data = await annRes.json();
        setAnnouncements(data.announcements || []);
      }

      if (calRes.ok) {
        const data = await calRes.json();
        setCalendarEvents(data.events || []);
      }

      if (currentUser?.role === 'HOD') {
        const auditRes = await fetch('/api/audit-logs?limit=25');
        if (auditRes.ok) {
          const data = await auditRes.json();
          setAuditLogs(data.logs || []);
        }
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSharedData();
  }, [currentUser]);

  const markNotificationRead = async (id: string) => {
    await fetch(`/api/notifications/${id}/read`, { method: 'POST' });
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const publishAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnnTitle || !newAnnContent) return;
    try {
      const res = await fetch('/api/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: newAnnTitle, content: newAnnContent, isPinned: true }),
      });
      if (res.ok) {
        setNewAnnTitle('');
        setNewAnnContent('');
        setStatusMsg('Announcement published successfully.');
        fetchSharedData();
      }
    } catch (err: any) {
      setStatusMsg(`Error: ${err.message}`);
    }
  };

  return (
    <div className="bg-white rounded-3 shadow-sm border p-4">
      {/* Top Banner */}
      <div className="d-md-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
        <div>
          <div className="d-flex align-items-center">
            <span className="badge bg-secondary px-3 py-2 fs-6 me-2 d-flex align-items-center">
              Shared Modules & Reporting
            </span>
            <span className="text-muted small">PDF/Excel Engines, Notifications, Academic Calendar & Audit Trail</span>
          </div>
          <p className="text-muted small mt-1 mb-0">
            Export official formatted reports, stay updated on department milestones, and review immutable security event logs.
          </p>
        </div>
        <div className="mt-3 mt-md-0">
          <button
            type="button"
            className="btn btn-outline-secondary btn-sm d-flex align-items-center"
            onClick={fetchSharedData}
            disabled={loading}
          >
            <RefreshCw size={14} className={`me-1 ${loading ? 'spin' : ''}`} /> Refresh Data
          </button>
        </div>
      </div>

      {statusMsg && (
        <div className="alert alert-info py-2 small mb-4" role="alert">
          {statusMsg}
        </div>
      )}

      {/* Sub-Tabs */}
      <ul className="nav nav-pills mb-4 border-bottom pb-2">
        <li className="nav-item">
          <button
            className={`nav-link btn-sm py-2 px-3 fw-semibold ${subTab === 'reports' ? 'active' : ''}`}
            onClick={() => setSubTab('reports')}
          >
            <FileSpreadsheet size={16} className="me-1 inline" /> Export Reports (PDF & Excel)
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link btn-sm py-2 px-3 fw-semibold ${subTab === 'notifications' ? 'active' : ''}`}
            onClick={() => setSubTab('notifications')}
          >
            <Bell size={16} className="me-1 inline" /> Notifications ({notifications.filter((n) => !n.isRead).length})
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link btn-sm py-2 px-3 fw-semibold ${subTab === 'announcements' ? 'active' : ''}`}
            onClick={() => setSubTab('announcements')}
          >
            <Megaphone size={16} className="me-1 inline" /> Department Announcements
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link btn-sm py-2 px-3 fw-semibold ${subTab === 'calendar' ? 'active' : ''}`}
            onClick={() => setSubTab('calendar')}
          >
            <Calendar size={16} className="me-1 inline" /> Academic Calendar
          </button>
        </li>
        {currentUser?.role === 'HOD' && (
          <li className="nav-item">
            <button
              className={`nav-link btn-sm py-2 px-3 fw-semibold ${subTab === 'audit' ? 'active' : ''}`}
              onClick={() => setSubTab('audit')}
            >
              <ShieldCheck size={16} className="me-1 inline" /> Audit Logs
            </button>
          </li>
        )}
      </ul>

      {/* SubTab 1: Reports & Exports */}
      {subTab === 'reports' && (
        <div>
          <h6 className="fw-bold text-dark mb-3">Live Document & Report Generation Center</h6>
          <p className="text-muted small mb-4">
            Click any report below to generate and stream real formatted PDF or Excel documents produced by PDFKit and ExcelJS:
          </p>

          <div className="row g-3">
            <div className="col-md-6 col-lg-4">
              <div className="card h-100 border p-3 bg-light">
                <div className="d-flex align-items-center mb-2">
                  <FileText className="text-danger me-2" size={24} />
                  <div>
                    <div className="fw-bold text-dark small">Project Summary (PDF)</div>
                    <div className="text-muted" style={{ fontSize: '0.75rem' }}>Engine: PDFKit</div>
                  </div>
                </div>
                <p className="small text-secondary mb-3">
                  Comprehensive breakdown of team, approved proposal, mentor, and milestone timeline.
                </p>
                <a
                  href="/api/reports/project-summary/proj-01/pdf"
                  className="btn btn-outline-danger btn-sm mt-auto d-flex align-items-center justify-content-center"
                  download
                >
                  <Download size={14} className="me-1" /> Download PDF Report
                </a>
              </div>
            </div>

            <div className="col-md-6 col-lg-4">
              <div className="card h-100 border p-3 bg-light">
                <div className="d-flex align-items-center mb-2">
                  <Award className="text-primary me-2" size={24} />
                  <div>
                    <div className="fw-bold text-dark small">Completion Certificate (PDF)</div>
                    <div className="text-muted" style={{ fontSize: '0.75rem' }}>Landscape Certificate</div>
                  </div>
                </div>
                <p className="small text-secondary mb-3">
                  Official capstone project completion certificate with border graphics and signoffs.
                </p>
                <a
                  href="/api/reports/certificate/proj-01/pdf"
                  className="btn btn-outline-primary btn-sm mt-auto d-flex align-items-center justify-content-center"
                  download
                >
                  <Download size={14} className="me-1" /> Download Certificate
                </a>
              </div>
            </div>

            <div className="col-md-6 col-lg-4">
              <div className="card h-100 border p-3 bg-light">
                <div className="d-flex align-items-center mb-2">
                  <FileSpreadsheet className="text-success me-2" size={24} />
                  <div>
                    <div className="fw-bold text-dark small">Projects Catalog (Excel)</div>
                    <div className="text-muted" style={{ fontSize: '0.75rem' }}>Engine: ExcelJS</div>
                  </div>
                </div>
                <p className="small text-secondary mb-3">
                  Structured spreadsheet of department projects, teams, leaders, tech stack, and progress.
                </p>
                <a
                  href="/api/reports/department-catalog/excel"
                  className="btn btn-outline-success btn-sm mt-auto d-flex align-items-center justify-content-center"
                  download
                >
                  <Download size={14} className="me-1" /> Download .xlsx Sheet
                </a>
              </div>
            </div>

            {currentUser?.role === 'HOD' && (
              <>
                <div className="col-md-6 col-lg-4">
                  <div className="card h-100 border p-3 bg-light">
                    <div className="d-flex align-items-center mb-2">
                      <FileSpreadsheet className="text-success me-2" size={24} />
                      <div>
                        <div className="fw-bold text-dark small">Mentor Workload (Excel)</div>
                        <div className="text-muted" style={{ fontSize: '0.75rem' }}>HOD Administrative Export</div>
                      </div>
                    </div>
                    <p className="small text-secondary mb-3">
                      Allocation balances, quotas, and utilization metrics across all department mentors.
                    </p>
                    <a
                      href="/api/reports/mentor-workload/excel"
                      className="btn btn-outline-success btn-sm mt-auto d-flex align-items-center justify-content-center"
                      download
                    >
                      <Download size={14} className="me-1" /> Download Workload .xlsx
                    </a>
                  </div>
                </div>

                <div className="col-md-6 col-lg-4">
                  <div className="card h-100 border p-3 bg-light">
                    <div className="d-flex align-items-center mb-2">
                      <FileText className="text-danger me-2" size={24} />
                      <div>
                        <div className="fw-bold text-dark small">Department Marksheet (PDF)</div>
                        <div className="text-muted" style={{ fontSize: '0.75rem' }}>Official Moderated Marks</div>
                      </div>
                    </div>
                    <p className="small text-secondary mb-3">
                      Official department marksheet with total scores, moderated marks, and final letter grades.
                    </p>
                    <a
                      href="/api/reports/department-marksheet/pdf"
                      className="btn btn-outline-danger btn-sm mt-auto d-flex align-items-center justify-content-center"
                      download
                    >
                      <Download size={14} className="me-1" /> Download Marksheet PDF
                    </a>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* SubTab 2: Notifications */}
      {subTab === 'notifications' && (
        <div>
          <h6 className="fw-bold text-dark mb-3">Your In-App Notifications</h6>
          <div className="d-flex flex-column gap-2">
            {notifications.length > 0 ? (
              notifications.map((n) => (
                <div
                  key={n.id}
                  className={`p-3 border rounded d-flex justify-content-between align-items-center ${
                    n.isRead ? 'bg-light' : 'bg-primary-subtle border-primary-subtle'
                  }`}
                >
                  <div>
                    <div className="fw-semibold text-dark small">{n.title}</div>
                    <div className="text-secondary small">{n.message}</div>
                    <div className="text-muted" style={{ fontSize: '0.7rem' }}>
                      {new Date(n.createdAt).toLocaleString()}
                    </div>
                  </div>
                  {!n.isRead && (
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm py-1 px-2"
                      style={{ fontSize: '0.75rem' }}
                      onClick={() => markNotificationRead(n.id)}
                    >
                      Mark Read
                    </button>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-4 text-muted bg-light border rounded">
                No notifications found.
              </div>
            )}
          </div>
        </div>
      )}

      {/* SubTab 3: Announcements */}
      {subTab === 'announcements' && (
        <div>
          {currentUser?.role === 'HOD' && (
            <div className="card border p-3 bg-light mb-4">
              <h6 className="fw-bold text-dark mb-2">Publish Department Announcement</h6>
              <form onSubmit={publishAnnouncement}>
                <div className="mb-2">
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    placeholder="Announcement Title..."
                    value={newAnnTitle}
                    onChange={(e) => setNewAnnTitle(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-2">
                  <textarea
                    className="form-control form-control-sm"
                    rows={2}
                    placeholder="Announcement content..."
                    value={newAnnContent}
                    onChange={(e) => setNewAnnContent(e.target.value)}
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary btn-sm">
                  Publish to Department
                </button>
              </form>
            </div>
          )}

          <h6 className="fw-bold text-dark mb-3">Active Department Announcements</h6>
          <div className="d-flex flex-column gap-3">
            {announcements.map((a) => (
              <div key={a.id} className="card border p-3 bg-white">
                <div className="d-flex justify-content-between align-items-start mb-1">
                  <h6 className="fw-bold text-dark mb-0">{a.title}</h6>
                  {a.isPinned && <span className="badge bg-warning text-dark">PINNED</span>}
                </div>
                <div className="text-muted mb-2" style={{ fontSize: '0.75rem' }}>
                  By {a.authorName} ({a.authorRole}) • {new Date(a.createdAt).toLocaleDateString()}
                </div>
                <p className="small text-secondary mb-0">{a.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SubTab 4: Academic Calendar */}
      {subTab === 'calendar' && (
        <div>
          <h6 className="fw-bold text-dark mb-3">Academic Term Calendar & Defense Deadlines</h6>
          <div className="row g-3">
            {calendarEvents.map((e) => (
              <div key={e.id} className="col-md-6">
                <div className="border rounded p-3 bg-light h-100">
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <span className="fw-bold text-dark small">{e.title}</span>
                    <span className={`badge ${
                      e.category === 'DEADLINE' ? 'bg-danger' :
                      e.category === 'REVIEW' ? 'bg-primary' : 'bg-success'
                    }`}>
                      {e.category}
                    </span>
                  </div>
                  <div className="small text-muted mb-2">
                    <Clock size={12} className="me-1 inline" /> {e.startDate} {e.endDate !== e.startDate && `to ${e.endDate}`}
                  </div>
                  <p className="small text-secondary mb-0">{e.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SubTab 5: Audit Logs */}
      {subTab === 'audit' && currentUser?.role === 'HOD' && (
        <div>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h6 className="fw-bold text-dark mb-0">Department Security Audit Log Explorer</h6>
            <div className="input-group input-group-sm" style={{ width: 250 }}>
              <span className="input-group-text"><Search size={14} /></span>
              <input
                type="text"
                className="form-control"
                placeholder="Filter logs..."
                value={searchAudit}
                onChange={(e) => setSearchAudit(e.target.value)}
              />
            </div>
          </div>

          <div className="table-responsive">
            <table className="table table-bordered table-sm align-middle">
              <thead className="table-light small">
                <tr>
                  <th>Timestamp</th>
                  <th>Action</th>
                  <th>Resource</th>
                  <th>Actor</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody className="small font-monospace">
                {auditLogs
                  .filter((l) => !searchAudit || l.details.toLowerCase().includes(searchAudit.toLowerCase()) || l.action.toLowerCase().includes(searchAudit.toLowerCase()))
                  .map((log) => (
                    <tr key={log.id}>
                      <td className="text-muted">{new Date(log.timestamp).toLocaleString()}</td>
                      <td><span className="badge bg-dark">{log.action}</span></td>
                      <td>{log.resource}</td>
                      <td>{log.actorName}</td>
                      <td className="text-secondary">{log.details}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
