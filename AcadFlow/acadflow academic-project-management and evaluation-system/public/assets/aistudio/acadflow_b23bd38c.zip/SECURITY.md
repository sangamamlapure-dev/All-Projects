# AcadFlow — Security & Compliance Architecture

## 1. Authentication & Session Security
- **Server-Side Sessions**: Stateful sessions stored server-side.
- **HttpOnly Cookies**: Session tokens are transmitted exclusively via `HttpOnly`, `SameSite=Lax` (or `Strict`), and `Secure` (in production) cookies, mitigating XSS token theft.
- **Credential Storage**: Passwords hashed using `bcrypt` (work factor 12) or `argon2id`. Plaintext passwords are never logged, persisted, or returned in API responses.
- **Account Invalidation**: Updating credentials or security events immediately invalidates active sessions across devices.
- **Account Recovery**: Password reset tokens are cryptographically random, one-time use, and expire after 15 minutes.

## 2. Resource-Level Authorization & IDOR Defense
- **Zero Client Trust**: Client-supplied roles, department IDs, approval statuses, and grades are never trusted. All access decisions are calculated from `req.session.userId` and verified against the database.
- **Department Boundary**: HOD users can only query, modify, or export records belonging to `user.departmentId`.
- **Assignment Scoping**: Project Mentors and External Evaluators are restricted to projects where an active `MentorAssignment` or `EvaluatorAssignment` exists.
- **Student Ownership**: Students can only inspect or modify projects and teams where they are confirmed members in `TeamMembership`.

## 3. Input Validation & Injection Mitigation
- **Server-Side Validation**: All incoming request payloads (JSON, query parameters, route params) are strictly validated using `Zod` schemas before executing business logic.
- **SQL Injection Prevention**: All queries execute through Prisma ORM using parameterized SQL. Raw queries without parameter binding are strictly prohibited.
- **Output Sanitization**: Dynamic user input rendered in frontend views is escaped to prevent Cross-Site Scripting (XSS).

## 4. Private File Storage & Path Traversal Prevention
- **Isolated Storage**: Uploaded documents are stored in a private directory outside web roots.
- **Randomized Storage Keys**: Files are stored with cryptographically random UUID keys (e.g. `uuidv4()`), completely decoupling filesystem paths from user-provided filenames.
- **Signature & MIME Validation**: File uploads are verified for permitted extensions and MIME types (`pdf`, `docx`, `pptx`, `xlsx`, `zip`, approved images) and constrained by a strict file size ceiling (e.g. 25MB).
- **Authorized Streaming**: Documents are accessed exclusively via authenticated streaming endpoints that verify resource-level download permissions. Predictable public URLs are prohibited.

## 5. Audit Logging & Non-Repudiation
- **Security Audit Trails**: High-impact administrative actions (account suspension, proposal approval/rejection, mentor assignment, rubric adjustments, grade moderation, result publication) are written to an append-only `AuditLog` table capturing actor ID, department ID, action type, resource ID, client IP, and timestamp.
- **Evaluation Immutability**: Once an External Evaluator finalizes a score, it cannot be modified by any party without an audited, logged HOD administrative reopening workflow.

## 6. Centralized Error Handling & Redaction
- In production (`NODE_ENV === 'production'`), error middleware suppresses internal stack traces, database schema details, and file paths, returning standard generic error structures to clients while writing redacted logs server-side.
