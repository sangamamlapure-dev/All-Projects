import { PrismaClient } from '@prisma/client';

export const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
});

export interface DatabaseHealth {
  configured: boolean;
  connected: boolean;
  provider: string;
  message: string;
}

export async function getDatabaseHealth(): Promise<DatabaseHealth> {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    return {
      configured: false,
      connected: false,
      provider: 'mysql',
      message: 'DATABASE_URL is not configured in environment.',
    };
  }

  try {
    // Perform low-overhead database health query
    await prisma.$queryRaw`SELECT 1`;
    return {
      configured: true,
      connected: true,
      provider: 'mysql',
      message: 'Successfully connected to MySQL 8 database.',
    };
  } catch (err: any) {
    return {
      configured: true,
      connected: false,
      provider: 'mysql',
      message: `MySQL connection offline: ${err.message?.split('\n')[0] || 'Connection refused or host unreachable.'}`,
    };
  }
}

export default prisma;
