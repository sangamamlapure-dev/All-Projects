# AcadFlow — Academic Project Management and Evaluation System

[![Phase](https://img.shields.io/badge/Phase-Phase%201%20Foundation-blue.svg)](#)
[![Status](https://img.shields.io/badge/Status-Verified-brightgreen.svg)](#)
[![Roles](https://img.shields.io/badge/Roles-Strictly%204%20Roles-purple.svg)](#)

AcadFlow is a production-oriented, full-stack Academic Project Management and Evaluation System engineered for engineering colleges, academic departments, project mentors, students, and external evaluators.

---

## 1. Authoritative Four-Role Model
AcadFlow enforces strictly four application roles. HOD is the Department Administrator who owns the Admin Panel. There is no separate `SYSTEM_ADMIN`, `SUPER_ADMIN`, or fifth role:

1. **`HOD`**: Head of Department / Department Administrator owning user management, team management, proposal approvals, mentor allocation, evaluator assignment, rubric configuration, and result publication.
2. **`STUDENT`**: Enrolled students managing project proposals, team memberships, milestone tasks, file uploads, and viewing authorized published results.
3. **`PROJECT_MENTOR`**: Faculty project supervisor guiding explicitly assigned teams, conducting reviews, recording meeting minutes, and approving corrections.
4. **`EXTERNAL_EVALUATOR`**: External examiners evaluating explicitly assigned projects using standardized rubrics and submitting finalized grades.

---

## 2. Technology Stack
- **Frontend**: React 19, TypeScript, Vite, Bootstrap 5, Lucide React, Zod.
- **Backend**: Node.js LTS, Express.js, TypeScript, REST API, Centralized Error Handling.
- **Database**: MySQL 8.0, Prisma ORM, Prisma Migrate.
- **Testing**: Vitest, Supertest, React Testing Library.

---

## 3. Quickstart Guide (Windows PowerShell)

Target Directory: `C:\MYPROJECT\AcadFlow`

```powershell
# 1. Clone or navigate to project directory
cd C:\MYPROJECT\AcadFlow

# 2. Copy safe environment variables
Copy-Item .env.example .env

# 3. Install dependencies
npm install

# 4. Run automated test suite
npm test

# 5. Start full-stack development server
npm run dev
```

The application will start on `http://localhost:3000`. The Express backend serves `/api/health` and Vite serves the React SPA via middleware.

---

## 4. Phase 1 Verification Status
- **Backend Health Check**: `GET /api/health` verified with HTTP 200 OK, returning service uptime, version, and the four verified roles.
- **Automated Tests**: Vitest + Supertest integration suite passing (`tests/health.test.ts`).
- **Centralized Error Handling**: Sanitized error responses without stack leaks in non-development modes.
- **Requirement Traceability**: Initialized in `REQUIREMENT_TRACEABILITY.md`. Historical predecessor 25-feature list marked as `BLOCKED` awaiting original document input.

---

## 5. Documentation Directory
- [Master Development Plan](DEVELOPMENT_PLAN.md)
- [Requirement Traceability](REQUIREMENT_TRACEABILITY.md)
- [Feature Status Registry](FEATURE_STATUS.md)
- [Development Log](DEVELOPMENT_LOG.md)
- [System Architecture](ARCHITECTURE.md)
- [Database Schema Design](DATABASE_SCHEMA.md)
- [Permissions Matrix](PERMISSIONS_MATRIX.md)
- [Security Architecture](SECURITY.md)
- [Deployment Guide](DEPLOYMENT.md)
