# AcadFlow — Master Development Plan

## Project Overview
AcadFlow is a production-oriented Academic Project Management and Evaluation System built for engineering colleges, academic departments, project mentors, students, and external evaluators.

**Technology Stack:**
- **Frontend**: React 19, TypeScript, Vite, Bootstrap 5, Lucide React, React Hook Form, Zod.
- **Backend**: Node.js, Express.js, TypeScript, REST API, Centralized Error Handling.
- **Database**: MySQL 8, Prisma ORM, Prisma Migrate.
- **Security**: HttpOnly server-side sessions, Argon2id/bcrypt, Helmet, CSRF protection, resource-level RBAC.
- **Testing**: Vitest, Supertest, React Testing Library, Playwright.

---

## Sequential Development Phases

### Phase 1: Foundation (COMPLETED & VERIFIED)
- [x] Inspect environment, tools, and workspace files.
- [x] Search for original specifications and catalog requirements.
- [x] Establish `REQUIREMENT_TRACEABILITY.md` (flagging missing predecessor 25-feature list as `BLOCKED`).
- [x] Initialize full-stack monorepo with React + TypeScript + Vite + Bootstrap 5 and Express.js + TypeScript.
- [x] Implement real `GET /api/health` endpoint with metadata and 4-role verification.
- [x] Implement centralized error handling middleware and sanitized error responses.
- [x] Add automated Vitest + Supertest integration test suite (`tests/health.test.ts`).
- [x] Establish safe `.env.example` and production-ready `.gitignore`.
- [x] Create comprehensive architectural and operational documentation suite.

### Phase 2: Database & Prisma ORM
- [ ] Install Prisma ORM and configure `@prisma/client` with MySQL provider.
- [ ] Define comprehensive schema containing all entities:
  - Users, Role enum (HOD, STUDENT, PROJECT_MENTOR, EXTERNAL_EVALUATOR), Profiles.
  - Departments, AcademicYears, Semesters, SystemSettings.
  - Teams, TeamMemberships, Proposals, ProposalRevisions, MentorAssignments.
  - Milestones, Tasks, TaskComments, ProgressUpdates.
  - Documents, DocumentVersions, Submissions.
  - Reviews, ReviewSchedules, Evaluations, Rubrics, RubricCriteria, EvaluationScores, Results.
  - Notifications, Announcements, CalendarEvents, AuditLogs.
- [ ] Create initial Prisma migration.
- [ ] Write seed script (`prisma/seed.ts`) with deterministic test accounts for each of the 4 roles.
- [ ] Test relationships, constraints, cascading rules, and indexes.

### Phase 3: Authentication, Sessions & RBAC
- [ ] Implement secure server-side session management with HttpOnly cookies.
- [ ] Implement password hashing with bcrypt/argon2id.
- [ ] Implement login, logout, session expiry, and session invalidation.
- [ ] Implement account recovery with one-time expiring tokens.
- [ ] Implement strict role-based access control middleware for the 4 roles.
- [ ] Enforce department-level isolation for HOD operations.
- [ ] Enforce project-level assignment isolation for Mentors and Evaluators.
- [ ] Enforce team membership boundaries for Students.
- [ ] Automated tests for authorized and denied operations.

### Phase 4: Shared UI System & Role Dashboards
- [ ] Bootstrap 5 layout system with responsive sidebar, navbar, and toast alerts.
- [ ] Build HOD Department Admin Panel:
  - Department overview, user management, team management, proposal approvals, mentor allocation.
- [ ] Build Student Dashboard:
  - Team status, proposal status, task board, milestone timeline, submissions, results.
- [ ] Build Project Mentor Dashboard:
  - Assigned projects, review schedules, submission review, feedback tracking.
- [ ] Build External Evaluator Dashboard:
  - Assigned evaluations, rubric scoring form, outcome comments, submission finalization.

### Phase 5: Core Academic Lifecycle Workflows
- [ ] Department and academic term setup by HOD.
- [ ] Student team formation and proposal submission with validation.
- [ ] HOD review: approve, reject, or request revisions.
- [ ] Mentor allocation with workload balancing view.
- [ ] Milestone planning and student progress updates.
- [ ] Review scheduling, meeting minutes, and feedback recording.
- [ ] Final submission (documents, presentations, reports).
- [ ] Evaluator assignment and rubric-based score entry.
- [ ] Score moderation, result approval, and official publication.

### Phase 6: Shared Modules
- [ ] In-app notifications and targeted department announcements.
- [ ] Academic calendar and deadline reminders.
- [ ] Private file storage service with access control and MIME validation.
- [ ] PDF report generation using PDFKit (Project summaries, evaluation sheets).
- [ ] Excel report generation using ExcelJS (Department marksheets, mentor workload).
- [ ] Search, filtering, and pagination utilities.
- [ ] Security audit logging for sensitive actions.

### Phase 7: Original & Supplementary Features
- [ ] Unblock and implement original 25 feature areas once specifications are provided.
- [ ] Implement Section 14 real-world enhancements (proposal similarity warning, conflict of interest declarations, portfolio export, meeting action items).

### Phase 8: Testing, Security & Hardening
- [ ] Comprehensive unit and integration test coverage.
- [ ] End-to-end user journey tests.
- [ ] Security audits: SQL injection, IDOR, privilege escalation, CSRF, path traversal.
- [ ] Rate limiting on authentication routes.

### Phase 9: Deployment & Production Readiness
- [ ] Production build verification (`npm run build`).
- [ ] Environment variable configuration and deployment documentation.
- [ ] Backup, restore, and rollback procedures.
