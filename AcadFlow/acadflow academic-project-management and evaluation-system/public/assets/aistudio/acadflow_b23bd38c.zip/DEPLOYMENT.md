# AcadFlow — Deployment & Operations Guide

## 1. System Requirements & Environment
- **Runtime**: Node.js 20.x or 22.x LTS
- **Package Manager**: npm 10.x+
- **Database**: MySQL 8.0+
- **VCS**: Git 2.34+
- **Preferred Development Path**: `C:\MYPROJECT\AcadFlow` (Windows PowerShell) or Linux `/app/applet`

---

## 2. Windows PowerShell Setup Instructions

### Step 1: Clone & Navigate
```powershell
# Open PowerShell as Administrator or standard user
cd C:\MYPROJECT\AcadFlow
```

### Step 2: Environment Setup
```powershell
# Copy the safe example configuration to .env
Copy-Item .env.example .env

# Edit .env with your local MySQL credentials and session secret
notepad .env
```

### Step 3: Install Dependencies
```powershell
npm install
```

### Step 4: Run Health & Verification Tests
```powershell
npm test
```

### Step 5: Start Development Server
```powershell
npm run dev
# The full-stack application will be available at http://localhost:3000
```

---

## 3. Database Initialization (Phase 2 Preparation)
When MySQL 8 is configured:
```powershell
# Generate Prisma Client
npx prisma generate

# Run migrations against development database
npx prisma migrate dev --name init_schema

# Seed deterministic development accounts for the 4 roles
npx prisma db seed
```

---

## 4. Production Build & Deployment

### Step 1: Build Frontend Assets
```powershell
npm run build
```

### Step 2: Set Production Environment
```powershell
$env:NODE_ENV="production"
$env:PORT="3000"
```

### Step 3: Start Production Server
```powershell
npm start
```

---

## 5. Backup, Restore & Rollback Runbooks

### 5.1 Database Backup (mysqldump)
```bash
# Full logical database dump with routines and triggers
mysqldump -u acadflow_user -p --single-transaction --quick --routines --triggers acadflow_prod > backup_$(date +%F_%T).sql
```

### 5.2 Database Restore
```bash
# Restore from logical backup
mysql -u acadflow_user -p acadflow_prod < backup_YYYY-MM-DD.sql
```

### 5.3 Rollback Strategy
- Keep timestamped Prisma migration records in `prisma/migrations`.
- To roll back a release:
  1. Revert git commit to last stable tag.
  2. Rebuild client assets with `npm run build`.
  3. Restart the Node process.
